/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.ifpe.services;

import br.com.ifpe.entities.Procedimento;
import br.com.ifpe.exception.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;

@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class ProcedimentoServico extends Servico<Procedimento>{
    
    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(Procedimento procedimento) throws ExcecaoNegocio {
        checarExistencia(Procedimento.PROCEDIMENTO_POR_NOME, procedimento.getNomeProcedimento());
        entityManager.persist(procedimento);
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(Procedimento procedimento) throws ExcecaoNegocio {
        checarNaoExistencia(Procedimento.PROCEDIMENTO_POR_ID, new Object[]{procedimento.getId()});        
        entityManager.merge(procedimento);
        entityManager.flush();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(Procedimento procedimento) throws ExcecaoNegocio {
        procedimento = entityManager.merge(procedimento);
        if (procedimento.isInativo()) {
            entityManager.remove(procedimento);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        Procedimento procedimento = getProcedimento(cpf);
        remover(procedimento);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<Procedimento> getProcedimentos() {
        return getEntidades(Procedimento.PROCEDIMENTOS);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public Procedimento getProcedimento(String desc) {
        return super.getEntidade(Procedimento.PROCEDIMENTO_POR_NOME, new Object[]{desc});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public Procedimento criar() {
        return new Procedimento();
    }
}
