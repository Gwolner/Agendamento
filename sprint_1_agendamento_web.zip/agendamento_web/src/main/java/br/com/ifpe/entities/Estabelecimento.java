package br.com.ifpe.entities;

import java.io.Serializable;
import javax.persistence.Access;
import javax.persistence.AccessType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="estabelecimento")
@Access(AccessType.FIELD)
@NamedQueries(
        {
            @NamedQuery(
                    name = Estabelecimento.ESTABELECIMENTO_POR_CNPJ,
                    query = "SELECT e FROM Estabelecimento e WHERE e.cnpj = ?1"
            ),
            @NamedQuery(
                    name = Estabelecimento.ESTABELECIMENTOS,
                    query = "SELECT e FROM Estabelecimento e ORDER BY e.razaoSocial"
            ),
             @NamedQuery(
                    name = Estabelecimento.ESTABELECIMENTO_POR_ID,
                    query = "SELECT e FROM Estabelecimento e WHERE e.id = ?1"
            ) 
        }
)
public class Estabelecimento extends Entidade implements Serializable{
    
    public static final String ESTABELECIMENTOS = "Estabelecimentos";
    public static final String ESTABELECIMENTO_POR_CNPJ = "EstabelecimentoPorCNPJ";
    public static final String ESTABELECIMENTO_POR_ID = "EstabelecimentoPorId";
    
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name = "id_estabelecimento")
//    private Long idEstabelecimento;
    
    @NotNull
    @Pattern(regexp = "[0-9]{2}.[0-9]{3}.[0-9]{3}/[0-9]{4}-[0-9]{2}")
    @Column(name="cnpj", length = 18)
    private String cnpj;
    
    @NotNull
    @Column(name="sala", length = 30)
    private String sala;
    
    @NotNull
    @Column(name="endereco", length = 50)
    private String endereco;
    
    @NotNull
    @Column(name = "razao_social", length = 50)
    private String razaoSocial;

//    public Long getIdEstabelecimento() {
//        return idEstabelecimento;
//    }
//
//    public void setIdEstabelecimento(Long idEstabelecimento) {
//        this.idEstabelecimento = idEstabelecimento;
//    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getSala() {
        return sala;
    }

    public void setSala(String sala) {
        this.sala = sala;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }
}
