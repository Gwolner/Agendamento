/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.ifpe.beans;

import br.com.ifpe.entities.Estabelecimento;
import br.com.ifpe.exception.ExcecaoNegocio;
import br.com.ifpe.services.EstabelecimentoServico;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;


@RequestScoped
@Named
public class EstabelecimentoBean extends Bean<Estabelecimento> implements Serializable{
    
    @Inject
    private EstabelecimentoServico estabelecimentoServico;

    private Estabelecimento estabelecimento = new Estabelecimento();
    
    private List<Estabelecimento> estabelecimentos;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(estabelecimentoServico.criar());
    }

    @Override
    protected boolean salvar(Estabelecimento entidade) throws ExcecaoNegocio {
        estabelecimentoServico.salvar(entidade);
        return true;
    }

    public Estabelecimento getEstabelecimento() {
        return estabelecimento;
    }

    public void setEstabelecimento(Estabelecimento estabelecimento) {
        this.estabelecimento = estabelecimento;
    }
    
    public List<Estabelecimento> getEstabelecimentos() {
        if (estabelecimentos == null) {
            estabelecimentos = estabelecimentoServico.getEstabelecimentos();
        }

        return estabelecimentos;
    }
    
//    //Métodos de apoio ao teste de DELETE
//    
//    public EstabelecimentoG getSelectedEstabelecimento() {
//        return selectedEstabelecimento;
//    }
// 
//    public void setSelectedEstabelecimento(EstabelecimentoG selectedEstabelecimento) {
//        this.selectedEstabelecimento = selectedEstabelecimento;
//    }
//    
//    //DELETE funcionando apenas para linha selecionada!
//    public void deleteSelected() throws ExcecaoNegocio {
//        estabelecimentoServico.remover(selectedEstabelecimento); //Remover do BD
//        estabelecimentos.remove(selectedEstabelecimento); //Remover da List
//        selectedEstabelecimento = null;
//    }    
    
    public void deleteEstabelecimento(Estabelecimento entidade) throws ExcecaoNegocio {
        estabelecimentoServico.remover(entidade); //Remover do BD
        estabelecimentos.remove(entidade); //Remover da List
//        selectedEstabelecimento = null;
    }
    
    //UPDATE funcionando!
    public void atualizarEstabelecimento() throws ExcecaoNegocio {
        System.out.println("##########################");
        System.out.println("this.estabelecimento: "+this.estabelecimento);
        System.out.println("ID: "+estabelecimento.getId());
        System.out.println("CNPJ: "+estabelecimento.getCnpj());
        System.out.println("Endereço: "+estabelecimento.getEndereco());
        System.out.println("Razao Social: "+estabelecimento.getRazaoSocial());
        System.out.println("Sala: "+estabelecimento.getSala());
        System.out.println("##########################");
        estabelecimentoServico.atualizar(this.estabelecimento);
    }
}
