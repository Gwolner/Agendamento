package br.com.ifpe.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="atendimento")
@NamedQueries(
        {
            @NamedQuery(
                    name = Atendimento.ATENDIMENTOS,
                    query = "SELECT a FROM Atendimento a ORDER BY a.ano"
            ),
             @NamedQuery(
                    name = Atendimento.ATENDIMENTO_POR_ID,
                    query = "SELECT a FROM Atendimento a WHERE a.id = ?1"
            ),
            @NamedQuery(
                    name = Atendimento.ATENDIMENTO_POR_CODIGO,
                    query = "SELECT a FROM Atendimento a WHERE a.codigoAtendimento = ?1"
            ),
            @NamedQuery(
                    name = Atendimento.AGENDAMENTO_POR_EMAIL,
                    query = "SELECT a FROM Atendimento a WHERE a.emailResponsavel = ?1"
            ),
            @NamedQuery(
                    name = Atendimento.ATENDIMENTOS_LIVRES,
                    query = "SELECT a FROM Atendimento a WHERE a.statusAtendimento = 'LV' ORDER BY a.ano"
            )
        }
)
public class Atendimento extends Entidade implements Serializable{
    
    public static final String ATENDIMENTOS = "Atendimentos";
    public static final String ATENDIMENTOS_LIVRES = "AtendimentosLivres";
    public static final String ATENDIMENTO_POR_ID = "AtendimentoPorId";
    public static final String ATENDIMENTO_POR_CODIGO = "AtendimentoPorCodigo";
    public static final String AGENDAMENTO_POR_EMAIL = "AtendimentoPorEmail";
    
    @NotNull
    @Column(name = "hora", length = 2)
    private int hora;
    
    @NotNull
    @Column(name = "minuto", length = 2)
    private int minuto;
    
    @NotNull
    @Column(name = "dia", length = 2)
    private int dia;
    
    @NotNull
    @Column(name = "mes", length = 2)
    private int mes;
    
    @NotNull
    @Column(name = "ano", length = 2)
    private int ano;
    
    @NotNull
    @Column(name = "codigo_atendimento", length = 5)
    private String codigoAtendimento;
    
    @NotNull
    @Column(name = "nome_responsavel", nullable=false, length = 30)
    private String nomeResponsavel;
    
    @Column(name="email_responsavel", nullable=false, length=255)
    private String emailResponsavel;
    
    @Column(name="status_atendimento", nullable=false, length=2)
    private String statusAtendimento;
    
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "procedimento_id", referencedColumnName = "id")
    private Procedimento procedimento;
    
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "estabelecimento_id", referencedColumnName = "id")
    private Estabelecimento estabelecimento;
    
    @OneToMany (cascade = CascadeType.ALL, mappedBy = "atendimento", 
            fetch = FetchType.LAZY)
    private List<Agendamento> agendamentos;

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getCodigoAtendimento() {
        return codigoAtendimento;
    }

    public void setCodigoAtendimento(String codigoAtendimento) {
        this.codigoAtendimento = codigoAtendimento;
    }

    public String getNomeResponsavel() {
        return nomeResponsavel;
    }

    public void setNomeResponsavel(String nomeResponsavel) {
        this.nomeResponsavel = nomeResponsavel;
    }

    public String getEmailResponsavel() {
        return emailResponsavel;
    }

    public void setEmailResponsavel(String emailResponsavel) {
        this.emailResponsavel = emailResponsavel;
    }

    public String getStatusAtendimento() {
        return statusAtendimento;
    }

    public void setStatusAtendimento(String statusAtendimento) {
        this.statusAtendimento = statusAtendimento;
    }
    
    public Procedimento getProcedimento() {
        return procedimento;
    }

    public void setProcedimento(Procedimento procedimento) {
        this.procedimento = procedimento;
    }

    public Estabelecimento getEstabelecimento() {
        return estabelecimento;
    }

    public void setEstabelecimento(Estabelecimento estabelecimento) {
        this.estabelecimento = estabelecimento;
    }

    public List<Agendamento> getAgendamentos() {
        return agendamentos;
    }

    public void setAgendamentos(List<Agendamento> agendamentos) {
        this.agendamentos = agendamentos;
    }
    
    

}
