/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.ifpe.beans;

import br.com.ifpe.entities.Agendamento;
import br.com.ifpe.entities.Atendimento;
import br.com.ifpe.entities.Estabelecimento;
import br.com.ifpe.entities.User;
import br.com.ifpe.exception.ExcecaoNegocio;
import br.com.ifpe.exception.MensagemExcecao;
import br.com.ifpe.managedbeans.LoginView;
import br.com.ifpe.services.AgendamentoServico;
import br.com.ifpe.services.AtendimentoServico;
import br.com.ifpe.services.EstabelecimentoServico;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJBException;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ConstraintViolationException;

/**
 *
 * @author wolner
 */
@RequestScoped
@Named
public class AgendamentoBean extends Bean<Agendamento> implements Serializable{
    
   @Inject
    private AgendamentoServico agendamentoServico;
    
    @Inject
    private AtendimentoServico atendimentoServico;

    private Agendamento agendamento = new Agendamento();
    
    private List<Agendamento> agendamentos;
    
    private List<Agendamento> agendamentosPorEmail;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(agendamentoServico.criar());
    }

    @Override
    protected boolean salvar(Agendamento entidade) throws ExcecaoNegocio {
        agendamentoServico.salvar(entidade);
        return true;
    }

    public Agendamento getAgendamento() {
        return agendamento;
    }

    public void setAgendamento(Agendamento agendamento) {
        this.agendamento = agendamento;
    }
    
    public List<Agendamento> getAgendamentos() {
        if (agendamentos == null) {
            agendamentos = agendamentoServico.getAgendamentos();
        }

        return agendamentos;
    }
    
    
    public List<Agendamento> getAgendamentosPorEmail() {        
       
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        Map<String, Object> sessionMap = externalContext.getSessionMap();
        User user = (User) externalContext.getSessionMap().get("User");
        
        if (agendamentosPorEmail == null) {
            agendamentosPorEmail = agendamentoServico.getAgendamentosPorEmail(user.getEmail());
        }

        return agendamentosPorEmail;
    }
    
    public List<Agendamento> getAgendamentosPorEmailResponsavel() {        
       
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        Map<String, Object> sessionMap = externalContext.getSessionMap();
        User user = (User) externalContext.getSessionMap().get("User");
        
        if (agendamentosPorEmail == null) {
            agendamentosPorEmail = agendamentoServico.getAgendamentosPorEmailResponsavel(user.getEmail());
        }

        return agendamentosPorEmail;
    }
    
    public List<Atendimento> getAtendimentos() {
        return atendimentoServico.getAtendimentos();
    }
    
    public List<Atendimento> getAtendimentosLivres() {
        return atendimentoServico.getAtendimentosLivres();
    }    
    
   @Override
    public void salvar() {
        
       this.getEntidade().getAtendimento().setStatusAtendimento("AG");
        
       try {
           atendimentoServico.atualizar(this.getEntidade().getAtendimento());
       } catch (ExcecaoNegocio ex) {
           Logger.getLogger(AgendamentoBean.class.getName()).log(Level.SEVERE, null, ex);
       }
       
        try {
            boolean sucesso = salvar(entidade);
            if (sucesso) {
                adicionarMessagem(FacesMessage.SEVERITY_INFO, "Cadastro realizado com sucesso!");
            }
        } catch (ExcecaoNegocio ex) {
            adicionarMessagem(FacesMessage.SEVERITY_WARN, ex.getMessage());
        } catch (EJBException ex) {
            if (ex.getCause() instanceof ConstraintViolationException) {
                MensagemExcecao mensagemExcecao = new MensagemExcecao(ex.getCause());
                adicionarMessagem(FacesMessage.SEVERITY_WARN, mensagemExcecao.getMensagem());
            } else {
                throw ex;
            }
        } finally {
            iniciarCampos();
        }
    }
    
    
//    //Métodos de apoio ao teste de DELETE
//    
//    public AgendamentoG getSelectedAgendamento() {
//        return selectedAgendamento;
//    }
// 
//    public void setSelectedAgendamento(AgendamentoG selectedAgendamento) {
//        this.selectedAgendamento = selectedAgendamento;
//    }
//    
//    //DELETE funcionando apenas para linha selecionada!
//    public void deleteSelected() throws ExcecaoNegocio {
//        agendamentoServico.remover(selectedAgendamento); //Remover do BD
//        agendamentos.remove(selectedAgendamento); //Remover da List
//        selectedAgendamento = null;
//    }    
    
    public void deleteAgendamento(Agendamento entidade) throws ExcecaoNegocio {
        
       entidade.getAtendimento().setStatusAtendimento("LV");
       
       try {
           atendimentoServico.atualizar(entidade.getAtendimento());
       } catch (ExcecaoNegocio ex) {
           Logger.getLogger(AgendamentoBean.class.getName()).log(Level.SEVERE, null, ex);
       }        
        
        agendamentoServico.remover(entidade); //Remover do BD
        
        
        //agendamentos.remove(entidade); //Remover da List
        
        
//        if(!agendamentosPorEmail.isEmpty()){
//            agendamentosPorEmail.remove(entidade); //Remover da List
//        }
        
//        selectedAgendamento = null;
    }
    
    //UPDATE funcionando!
    public void atualizarAgendamento() throws ExcecaoNegocio {
        agendamentoServico.atualizar(this.agendamento);
    }
}
