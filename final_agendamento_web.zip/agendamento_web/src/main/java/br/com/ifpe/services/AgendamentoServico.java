/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.ifpe.services;

import br.com.ifpe.entities.Agendamento;
import br.com.ifpe.exception.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;

@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class AgendamentoServico extends Servico<Agendamento>{
    
     //@RolesAllowed({ADMINISTRADOR})
    public void salvar(Agendamento agendamento) throws ExcecaoNegocio {
        entityManager.persist(agendamento);
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(Agendamento agendamento) throws ExcecaoNegocio {
        checarNaoExistencia(Agendamento.AGENDAMENTO_POR_ID, new Object[]{agendamento.getId()});        
        entityManager.merge(agendamento);
        entityManager.flush();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(Agendamento agendamento) throws ExcecaoNegocio {
        agendamento = entityManager.merge(agendamento);
        if (agendamento.isInativo()) {
            entityManager.remove(agendamento);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        Agendamento agendamento = getAgendamento(cpf);
        remover(agendamento);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<Agendamento> getAgendamentos() {
        return getEntidades(Agendamento.AGENDAMENTOS);
    }
    
    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<Agendamento> getAgendamentosPorEmail(String email) {
        return getEntidades(Agendamento.AGENDAMENTO_POR_EMAIL, new Object[]{email});
    }
    
    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<Agendamento> getAgendamentosPorEmailResponsavel(String email) {
        return getEntidades(Agendamento.AGENDAMENTO_POR_EMAIL_RESPONSAVEL, new Object[]{email});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public Agendamento getAgendamento(String desc) {
        return super.getEntidade(Agendamento.AGENDAMENTO_POR_EMAIL, new Object[]{desc});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public Agendamento criar() {
        return new Agendamento();
    }
}
