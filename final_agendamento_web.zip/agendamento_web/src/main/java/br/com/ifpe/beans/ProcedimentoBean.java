/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.ifpe.beans;

import br.com.ifpe.entities.Procedimento;
import br.com.ifpe.exception.ExcecaoNegocio;
import br.com.ifpe.services.ProcedimentoServico;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author wolner
 */
@RequestScoped
@Named
public class ProcedimentoBean extends Bean<Procedimento> implements Serializable{
    
    @Inject
    private ProcedimentoServico procedimentoServico;

    private Procedimento procedimento = new Procedimento();
    
    private List<Procedimento> procedimentos;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(procedimentoServico.criar());
    }

    @Override
    protected boolean salvar(Procedimento entidade) throws ExcecaoNegocio {
        procedimentoServico.salvar(entidade);
        return true;
    }

    public Procedimento getProcedimento() {
        return procedimento;
    }

    public void setProcedimento(Procedimento procedimento) {
        this.procedimento = procedimento;
    }
    
    public List<Procedimento> getProcedimentos() {
        if (procedimentos == null) {
            procedimentos = procedimentoServico.getProcedimentos();
        }

        return procedimentos;
    }
    
//    //Métodos de apoio ao teste de DELETE
//    
//    public ProcedimentoG getSelectedProcedimento() {
//        return selectedProcedimento;
//    }
// 
//    public void setSelectedProcedimento(ProcedimentoG selectedProcedimento) {
//        this.selectedProcedimento = selectedProcedimento;
//    }
//    
//    //DELETE funcionando apenas para linha selecionada!
//    public void deleteSelected() throws ExcecaoNegocio {
//        procedimentoServico.remover(selectedProcedimento); //Remover do BD
//        procedimentos.remove(selectedProcedimento); //Remover da List
//        selectedProcedimento = null;
//    }    
    
    public void deleteProcedimento(Procedimento entidade) throws ExcecaoNegocio {
        procedimentoServico.remover(entidade); //Remover do BD
        procedimentos.remove(entidade); //Remover da List
//        selectedProcedimento = null;
    }
    
    //UPDATE funcionando!
    public void atualizarProcedimento() throws ExcecaoNegocio {
        procedimentoServico.atualizar(this.procedimento);
    }
}
