package br.com.ifpe.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="agendamento")
@NamedQueries(
        {
            @NamedQuery(
                    name = Agendamento.AGENDAMENTOS,
                    query = "SELECT a FROM Agendamento a ORDER BY a.nomeCliente"
            ),
             @NamedQuery(
                    name = Agendamento.AGENDAMENTO_POR_ID,
                    query = "SELECT a FROM Agendamento a WHERE a.id = ?1"
            ),
            @NamedQuery(
                    name = Agendamento.AGENDAMENTO_POR_EMAIL,
                    query = "SELECT a FROM Agendamento a WHERE a.emailCliente = ?1"
            ),
            @NamedQuery(
                    name = Agendamento.AGENDAMENTO_POR_EMAIL_RESPONSAVEL,
                    query = "SELECT a FROM Agendamento a WHERE a.atendimento.emailResponsavel = ?1"
            ),
        }
)
public class Agendamento extends Entidade implements Serializable{
    
    public static final String AGENDAMENTOS = "Agendamentos";
    public static final String AGENDAMENTO_POR_ID = "AgendamentoPorId";
    public static final String AGENDAMENTO_POR_EMAIL = "AgendamentoPorEmail";
    public static final String AGENDAMENTO_POR_EMAIL_RESPONSAVEL = "AgendamentoPorEmailResponsavel";
    
    @NotNull
    @Column(name = "nome_cliente", nullable=false, length = 30)
    private String nomeCliente;
    
    @Column(name="email_cliente", nullable=false, length=255)
    private String emailCliente;
    
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "atendimento_id", referencedColumnName = "id")
    private Atendimento atendimento;

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public String getEmailCliente() {
        return emailCliente;
    }

    public void setEmailCliente(String emailCliente) {
        this.emailCliente = emailCliente;
    }

    public Atendimento getAtendimento() {
        return atendimento;
    }

    public void setAtendimento(Atendimento atendimento) {
        this.atendimento = atendimento;
    }
    
    
}
