/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.ifpe.beans;

import br.com.ifpe.entities.Agendamento;
import br.com.ifpe.entities.Atendimento;
import br.com.ifpe.entities.Procedimento;
import br.com.ifpe.entities.Estabelecimento;
import br.com.ifpe.entities.User;
import br.com.ifpe.exception.ExcecaoNegocio;
import br.com.ifpe.services.AtendimentoServico;
import br.com.ifpe.services.ProcedimentoServico;
import br.com.ifpe.services.EstabelecimentoServico;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author wolner
 */
@RequestScoped
@Named
public class AtendimentoBean extends Bean<Atendimento> implements Serializable{
    
    @Inject
    private AtendimentoServico atendimentoServico;
    
    @Inject
    private ProcedimentoServico procedimentoServico;
    
    @Inject
    private EstabelecimentoServico estabelecimentoServico;

    private Atendimento atendimento = new Atendimento();
    
    private List<Atendimento> atendimentos;
    
    private List<Atendimento> atendimentosPorEmail;
    
    @Override
    protected void iniciarCampos() {
        setEntidade(atendimentoServico.criar());
    }

    @Override
    protected boolean salvar(Atendimento entidade) throws ExcecaoNegocio {
        atendimentoServico.salvar(entidade);
        return true;
    }

    public Atendimento getAtendimento() {
        return atendimento;
    }

    public void setAtendimento(Atendimento atendimento) {
        this.atendimento = atendimento;
    }
    
    public List<Atendimento> getAtendimentos() {
        if (atendimentos == null) {
            atendimentos = atendimentoServico.getAtendimentos();
        }

        return atendimentos;
    }
    
    public List<Atendimento> getAtendimentosPorEmail() {        
       
        ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
        Map<String, Object> sessionMap = externalContext.getSessionMap();
        User user = (User) externalContext.getSessionMap().get("User");
        
        if (atendimentosPorEmail == null) {
            atendimentosPorEmail = atendimentoServico.getAtendimentosPorEmail(user.getEmail());
        }

        return atendimentosPorEmail;
    }
    
    public List<Procedimento> getProcedimentos() {
        return procedimentoServico.getProcedimentos();
    }
    
    public List<Estabelecimento> getEstabelecimentos() {
        return estabelecimentoServico.getEstabelecimentos();
    }
    
//    //Métodos de apoio ao teste de DELETE
//    
//    public AtendimentoG getSelectedAtendimento() {
//        return selectedAtendimento;
//    }
// 
//    public void setSelectedAtendimento(AtendimentoG selectedAtendimento) {
//        this.selectedAtendimento = selectedAtendimento;
//    }
//    
//    //DELETE funcionando apenas para linha selecionada!
//    public void deleteSelected() throws ExcecaoNegocio {
//        atendimentoServico.remover(selectedAtendimento); //Remover do BD
//        atendimentos.remove(selectedAtendimento); //Remover da List
//        selectedAtendimento = null;
//    }    
    
    public void deleteAtendimento(Atendimento entidade) throws ExcecaoNegocio {
        atendimentoServico.remover(entidade); //Remover do BD
        //atendimentos.remove(entidade); //Remover da List
//        selectedAtendimento = null;
    }
    
    //UPDATE funcionando!
    public void atualizarAtendimento() throws ExcecaoNegocio {
        atendimentoServico.atualizar(this.atendimento);
    }
}