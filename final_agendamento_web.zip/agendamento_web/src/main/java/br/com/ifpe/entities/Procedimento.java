package br.com.ifpe.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="procedimento")
@Access(AccessType.FIELD)
@NamedQueries(
        {
            @NamedQuery(
                    name = Procedimento.PROCEDIMENTO_POR_NOME,
                    query = "SELECT p FROM Procedimento p WHERE p.nomeProcedimento = ?1"
            ),
            @NamedQuery(
                    name = Procedimento.PROCEDIMENTO_POR_NATUREZA,
                    query = "SELECT p FROM Procedimento p WHERE p.naturezaProcedimento = ?1"
            ),
            @NamedQuery(
                    name = Procedimento.PROCEDIMENTOS,
                    query = "SELECT p FROM Procedimento p ORDER BY p.nomeProcedimento"
            ),
             @NamedQuery(
                    name = Procedimento.PROCEDIMENTO_POR_ID,
                    query = "SELECT p FROM Procedimento p WHERE p.id = ?1"
            ) 
        }
)
public class Procedimento extends Entidade implements Serializable{
    
    public static final String PROCEDIMENTOS = "Procedimentos";
    public static final String PROCEDIMENTO_POR_NATUREZA = "ProcedimentoPorNatureza";
    public static final String PROCEDIMENTO_POR_NOME = "ProcedimentoPorNome";
    public static final String PROCEDIMENTO_POR_ID = "ProcedimentoPorId";
    
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name = "id_procedimento")
//    private Long idProcedimento;
    
    @Column(name = "natureza_procedimento", length = 45)
    @NotNull
    private String naturezaProcedimento;
    
    @Column(name = "nome_procedimento", length = 45)
    @NotNull
    private String nomeProcedimento;
    
    @OneToMany (cascade = CascadeType.ALL, mappedBy = "procedimento", 
            fetch = FetchType.LAZY)
    private List<Atendimento> atendimentos;

    public String getNaturezaProcedimento() {
        return naturezaProcedimento;
    }

    public void setNaturezaProcedimento(String naturezaProcedimento) {
        this.naturezaProcedimento = naturezaProcedimento;
    }

    public String getNomeProcedimento() {
        return nomeProcedimento;
    }

    public void setNomeProcedimento(String nomeProcedimento) {
        this.nomeProcedimento = nomeProcedimento;
    }

    public List<Atendimento> getAtendimentos() {
        return atendimentos;
    }

    public void setAtendimentos(List<Atendimento> atendimentos) {
        this.atendimentos = atendimentos;
    }

}
