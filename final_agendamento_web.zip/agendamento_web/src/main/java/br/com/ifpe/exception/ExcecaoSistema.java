package br.com.ifpe.exception;

import javax.ejb.ApplicationException;

/**
 *
 * @author wolner
 */
@ApplicationException(rollback = true)
public class ExcecaoSistema extends RuntimeException{
    
    public ExcecaoSistema(Throwable causa) {
        super(causa);
    }
    
    @Override
    public String getMessage() {
        MensagemExcecao mensagemExcecao = new MensagemExcecao(this);
        return mensagemExcecao.getMensagem();
    }
}
