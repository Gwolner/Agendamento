/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.ifpe.services;

import br.com.ifpe.entities.Agendamento;
import br.com.ifpe.entities.Atendimento;
import br.com.ifpe.exception.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;

@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class AtendimentoServico extends Servico<Atendimento>{
    
    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(Atendimento atendimento) throws ExcecaoNegocio {
        checarExistencia(Atendimento.ATENDIMENTO_POR_CODIGO, atendimento.getCodigoAtendimento());
        entityManager.persist(atendimento);
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(Atendimento atendimento) throws ExcecaoNegocio {
        checarNaoExistencia(Atendimento.ATENDIMENTO_POR_ID, new Object[]{atendimento.getId()});        
        entityManager.merge(atendimento);
        entityManager.flush();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(Atendimento atendimento) throws ExcecaoNegocio {
        atendimento = entityManager.merge(atendimento);
        if (atendimento.isInativo()) {
            entityManager.remove(atendimento);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        Atendimento atendimento = getAtendimento(cpf);
        remover(atendimento);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<Atendimento> getAtendimentos() {
        return getEntidades(Atendimento.ATENDIMENTOS);
    }
    
    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<Atendimento> getAtendimentosLivres() {
        return getEntidades(Atendimento.ATENDIMENTOS_LIVRES);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<Atendimento> getAtendimentosPorEmail(String email) {
        return getEntidades(Atendimento.AGENDAMENTO_POR_EMAIL, new Object[]{email});
    }
    
    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public Atendimento getAtendimento(String desc) {
        return super.getEntidade(Atendimento.ATENDIMENTO_POR_CODIGO, new Object[]{desc});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public Atendimento criar() {
        return new Atendimento();
    }
}

