/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.ifpe.services;

import br.com.ifpe.entities.Estabelecimento;
import br.com.ifpe.exception.ExcecaoNegocio;
import java.util.List;
import javax.annotation.security.PermitAll;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;
import static javax.ejb.TransactionAttributeType.SUPPORTS;
import javax.ejb.TransactionManagement;
import static javax.ejb.TransactionManagementType.CONTAINER;
import javax.validation.executable.ExecutableType;
import javax.validation.executable.ValidateOnExecution;

@Stateless
@LocalBean
//@DeclareRoles({ADMINISTRADOR, USUARIO})
@TransactionManagement(CONTAINER)
@TransactionAttribute(REQUIRED)
@ValidateOnExecution(type = ExecutableType.NON_GETTER_METHODS)
public class EstabelecimentoServico extends Servico<Estabelecimento>{
    
    //@RolesAllowed({ADMINISTRADOR})
    public void salvar(Estabelecimento estabelecimento) throws ExcecaoNegocio {
        checarExistencia(Estabelecimento.ESTABELECIMENTO_POR_CNPJ, estabelecimento.getCnpj());
        entityManager.persist(estabelecimento);
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void atualizar(Estabelecimento estabelecimento) throws ExcecaoNegocio {
        checarNaoExistencia(Estabelecimento.ESTABELECIMENTO_POR_ID, new Object[]{estabelecimento.getId()});   
        System.out.println("##########################");
        System.out.println(estabelecimento.getId());
        System.out.println(estabelecimento.getCnpj());
        System.out.println(estabelecimento.getEndereco());
        System.out.println(estabelecimento.getRazaoSocial());
        System.out.println(estabelecimento.getSala());
        System.out.println("##########################");
        entityManager.merge(estabelecimento);
        entityManager.flush();
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(Estabelecimento estabelecimento) throws ExcecaoNegocio {
        estabelecimento = entityManager.merge(estabelecimento);
        if (estabelecimento.isInativo()) {
            entityManager.remove(estabelecimento);
        } else {
            throw new ExcecaoNegocio(ExcecaoNegocio.REMOVER_AUTOR);
        }
    }

    //@RolesAllowed({ADMINISTRADOR})
    public void remover(String cpf) throws ExcecaoNegocio {
        Estabelecimento estabelecimento = getEstabelecimento(cpf);
        remover(estabelecimento);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public List<Estabelecimento> getEstabelecimentos() {
        return getEntidades(Estabelecimento.ESTABELECIMENTOS);
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public Estabelecimento getEstabelecimento(String desc) {
        return super.getEntidade(Estabelecimento.ESTABELECIMENTO_POR_CNPJ, new Object[]{desc});
    }

    @TransactionAttribute(SUPPORTS)
    @PermitAll
    public Estabelecimento criar() {
        return new Estabelecimento();
    }
}
